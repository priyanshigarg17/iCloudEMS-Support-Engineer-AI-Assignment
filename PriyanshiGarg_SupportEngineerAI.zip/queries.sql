-- iCloudEMS Support Engineer AI Assignment
-- Task 3: SQL on exam_wise_report
-- Dialect: SQLite (accepted by assignment). CSV imported into this table.
-- Source rows loaded: 2,767.
-- Column names converted to snake_case.

-- CREATE TABLE (SQLite-compatible staging definition)
CREATE TABLE exam_wise_report (
    sr INTEGER,
    exam_session TEXT,
    academic_year TEXT,
    branch TEXT,
    department TEXT,
    class TEXT,
    semester TEXT,
    batch TEXT,
    admno TEXT,
    rollno INTEGER,
    student TEXT,
    division TEXT,
    course TEXT,
    code TEXT,
    type TEXT,
    alloted_empid TEXT,
    exam_name TEXT,
    marks_entry_status TEXT,
    marks_obtained REAL,
    max_marks REAL,
    freeze_unfreeze_status TEXT,
    scaled_marks REAL,
    scaled_maxmarks REAL,
    register_status TEXT,
    result_process TEXT,
    result_publish TEXT
);

-- Import the CSV into exam_wise_report using SQLite import or a client-side CSV importer.
-- The queries below assume the 2,767 CSV rows have been loaded.


-- 1. Count rows by exam_name and marks_entry_status
-- Result rows: 5
SELECT exam_name, marks_entry_status, COUNT(*) AS row_count
FROM exam_wise_report
GROUP BY exam_name, marks_entry_status
ORDER BY exam_name, marks_entry_status;


-- 2. Published results with marks Not Done or missing
-- Result rows: 1849
SELECT admno, student, code, course, exam_name
FROM exam_wise_report
WHERE result_publish = 'Published'
  AND (marks_entry_status = 'Not Done' OR marks_obtained IS NULL)
ORDER BY admno, code;


-- 3. Duplicate admno + code + exam_name groups
-- Result rows: 356
SELECT admno, code, exam_name, COUNT(*) AS occurrences
FROM exam_wise_report
GROUP BY admno, code, exam_name
HAVING COUNT(*) > 1
ORDER BY occurrences DESC, admno, code;


-- 4. Impossible marks
-- Result rows: 10
SELECT sr, admno, code, exam_name, marks_obtained, max_marks,
       scaled_marks, scaled_maxmarks
FROM exam_wise_report
WHERE marks_obtained < 0
   OR marks_obtained > max_marks
   OR (max_marks = scaled_maxmarks
       AND marks_obtained IS NOT NULL
       AND scaled_marks IS NOT NULL
       AND ABS(scaled_marks - marks_obtained) > 0.000001)
ORDER BY sr;


-- 5A. Preview original semester and cleaned semester
-- Result rows: 17
SELECT DISTINCT semester AS original_value,
       CASE UPPER(TRIM(semester))
         WHEN 'SEM I' THEN 'Sem I'
         WHEN 'SEM II' THEN 'Sem II'
         WHEN 'SEM III' THEN 'Sem III'
         WHEN 'SEM IV' THEN 'Sem IV'
         WHEN 'SEM V' THEN 'Sem V'
         WHEN 'SEM VI' THEN 'Sem VI'
         WHEN 'SEM VII' THEN 'Sem VII'
         WHEN 'SEM VIII' THEN 'Sem VIII'
         WHEN 'SEM IX' THEN 'Sem IX'
         ELSE TRIM(semester)
       END AS cleaned_value
FROM exam_wise_report
ORDER BY original_value;


-- 6. Missing scheme configuration list
-- Result rows: 273
SELECT department, semester, code, course,
       COUNT(DISTINCT admno) AS students_affected,
       COUNT(*) AS affected_rows
FROM exam_wise_report
WHERE exam_name = 'Scheme Not Found'
GROUP BY department, semester, code, course
ORDER BY students_affected DESC, affected_rows DESC;


-- Bonus. Daily exam-season exception monitoring
-- Result rows: 4
SELECT exam_session, academic_year, exam_name,
       COUNT(*) AS total_rows,
       SUM(CASE WHEN marks_obtained IS NULL THEN 1 ELSE 0 END) AS missing_marks,
       SUM(CASE WHEN exam_name = 'Scheme Not Found' THEN 1 ELSE 0 END) AS scheme_not_found,
       SUM(CASE WHEN marks_obtained < 0 OR marks_obtained > max_marks THEN 1 ELSE 0 END) AS impossible_marks
FROM exam_wise_report
GROUP BY exam_session, academic_year, exam_name
HAVING missing_marks > 0 OR scheme_not_found > 0 OR impossible_marks > 0
ORDER BY scheme_not_found DESC, missing_marks DESC;


-- 5B. Safe semester standardisation procedure.
-- IMPORTANT: Take a backup before updating. Review the preview (5A) first.
-- This creates a point-in-time copy; do not overwrite an existing backup table.
CREATE TABLE exam_wise_report_backup_20261124 AS
SELECT * FROM exam_wise_report;
-- Expected rows in backup: 2,767.

-- Run the UPDATE only after backup and approval. The WHERE clause limits changes
-- to known case variants. 'Sem 9' is deliberately not changed; confirm with the
-- academic master-data owner whether it means 'Sem IX'.
BEGIN TRANSACTION;

UPDATE exam_wise_report
SET semester = CASE UPPER(TRIM(semester))
    WHEN 'SEM I' THEN 'Sem I'
    WHEN 'SEM II' THEN 'Sem II'
    WHEN 'SEM III' THEN 'Sem III'
    WHEN 'SEM IV' THEN 'Sem IV'
    WHEN 'SEM V' THEN 'Sem V'
    WHEN 'SEM VI' THEN 'Sem VI'
    WHEN 'SEM VII' THEN 'Sem VII'
    WHEN 'SEM VIII' THEN 'Sem VIII'
    WHEN 'SEM IX' THEN 'Sem IX'
    ELSE semester
END
WHERE UPPER(TRIM(semester)) IN
    ('SEM I','SEM II','SEM III','SEM IV','SEM V','SEM VI','SEM VII','SEM VIII','SEM IX')
  AND semester <> CASE UPPER(TRIM(semester))
    WHEN 'SEM I' THEN 'Sem I'
    WHEN 'SEM II' THEN 'Sem II'
    WHEN 'SEM III' THEN 'Sem III'
    WHEN 'SEM IV' THEN 'Sem IV'
    WHEN 'SEM V' THEN 'Sem V'
    WHEN 'SEM VI' THEN 'Sem VI'
    WHEN 'SEM VII' THEN 'Sem VII'
    WHEN 'SEM VIII' THEN 'Sem VIII'
    WHEN 'SEM IX' THEN 'Sem IX'
    ELSE semester
  END;
-- Expected rows updated: 139 (verify on the target database before committing).
-- Validate changed values, then COMMIT; otherwise ROLLBACK.
-- COMMIT;
-- ROLLBACK;

-- Note: Query 3 returns 356 duplicate KEY GROUPS (716 involved rows).
-- Query 4 returns 10 records; negative marks and scaled mismatches overlap.
